
import React from 'react'
import { createRoot } from 'react-dom/client'
import TimeOffPage from './timeoff/TimeOffPage'
const root = createRoot(document.getElementById('root')!)
root.render(<TimeOffPage />)
